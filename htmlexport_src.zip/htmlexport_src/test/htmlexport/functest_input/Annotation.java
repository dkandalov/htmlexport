package htmlexport.functest_input;

/**
 * User: dima
 * Date: Dec 8, 2008
 * Time: 9:00:28 PM
 */
public @interface Annotation {
    public static int counter = 0;
}